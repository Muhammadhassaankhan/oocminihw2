package oocminihw2;

public class OOCMiniHW2 {

    public static void main(String[] args) {
        Truck truck = new Truck("Ford", "Pickup Truck", 4, 2);
        Helicopter helicopter = new Helicopter("Bell", "Rescue Helicopter", 2, 4);
        Sailboat sailboat = new Sailboat("Beneteau", "Sailing Yacht", 1, 6);

        // Demonstrate their functionality
        truck.accelerate(50);
        helicopter.accelerate(200);
        sailboat.hoistSail();

        System.out.println("Truck Speed: " + truck.getSpeed());
        System.out.println("Helicopter Speed: " + helicopter.getSpeed());
        System.out.println("Sailboat Sail Hoisted: " + sailboat.isSailHoisted());
    }
}
