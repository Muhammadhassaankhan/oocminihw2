package oocminihw2;

public interface Flyable extends Drivable {
    public void changeAltitude(float change);
    public float getAltitude();
}
