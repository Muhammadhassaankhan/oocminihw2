package oocminihw2;

public class Helicopter extends Vehicle implements Flyable {
    public Helicopter(String make, String type, int numWings, int numPassengers) {
        super(make, type, numPassengers);
        this.numWings = numWings;
    }

    @Override
    public void accelerate(float speed) {
        this.speed = speed;
    }

    @Override
    public void brake() {
        this speed = 0;
    }

    @Override
    public void turn(float angle) {
        // Implement turning logic for a helicopter
    }

    @Override
    public float getDirection() {
        return direction;
    }

    @Override
    public float getSpeed() {
        return speed;
    }

    @Override
    public String getMake() {
        return make;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public void changeAltitude(float change) {
        // Implement changing altitude logic for a helicopter
    }

    @Override
    public float getAltitude() {
        return 0; // Placeholder value
    }
}
