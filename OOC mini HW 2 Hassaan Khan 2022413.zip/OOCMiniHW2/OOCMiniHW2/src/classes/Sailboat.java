package oocminihw2;

public class Sailboat extends Vehicle implements Sailable {
    private boolean sailHoisted = false;

    public Sailboat(String make, String type, int numSails, int numPassengers) {
        super(make, type, numPassengers);
        this.numSails = numSails;
    }

    @Override
    public void hoistSail() {
        sailHoisted = true;
    }

    @Override
    public void lowerSail() {
        sailHoisted = false;
    }

    @Override
    public boolean isSailHoisted() {
        return sailHoisted;
    }

    @Override
    public void landHo() {
        // Implement logic for landing the sail on a sailboat
    }
}
