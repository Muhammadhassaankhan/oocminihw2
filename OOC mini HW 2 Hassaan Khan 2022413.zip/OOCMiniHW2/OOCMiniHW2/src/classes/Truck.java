package oocminihw2;

public class Truck extends Vehicle implements Drivable {
    public Truck(String make, String type, int numWheels, int numPassengers) {
        super(make, type, numPassengers);
        this.numWheels = numWheels;
    }

    @Override
    public void accelerate(float speed) {
        this.speed = speed;
    }

    @Override
    public void brake() {
        this.speed = 0;
    }

    @Override
    public void turn(float angle) {
        // Implement turning logic for a truck
    }

    @Override
    public float getDirection() {
        return direction;
    }

    @Override
    public float getSpeed() {
        return speed;
    }

    @Override
    public String getMake() {
        return make;
    }

    @Override
    public String getType() {
        return type;
    }
}
